# Online Course web app

This is the final "Online Course" web app developed as the final project for the IBM course:

**Developing Applications with SQL, Databases and Django**

The course is hosted byt the [IBM Developer Skills Network](https://labs.cognitiveclass.ai/)
and corresponds to the 8th course in the IBM Cloud Developer Professional Certification
